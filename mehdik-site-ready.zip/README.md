
# mehdik.site
Static site for Mehdi, deployed with **GitHub Pages** and mapped to the custom domain **mehdik.site**.

## Structure
- `index.html` — iPhone-style Hello splash.
- `about.html` — About page.
- `contact.html` — Contact form (mailto).
- `assets/style.css` — Shared styles.
- `assets/logo.svg` — Minimal gradient logo.
- `CNAME` — Custom domain mapping.

## Deploy
Commit/push to the repository's `main` branch. GitHub Pages will publish automatically.
